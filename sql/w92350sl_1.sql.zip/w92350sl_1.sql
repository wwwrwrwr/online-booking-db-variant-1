-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Май 22 2026 г., 16:03
-- Версия сервера: 8.0.34-26-beget-1-1
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `w92350sl_1`
--

-- --------------------------------------------------------

--
-- Структура таблицы `appointments`
--
-- Создание: Май 19 2026 г., 01:52
-- Последнее обновление: Май 21 2026 г., 08:18
--

DROP TABLE IF EXISTS `appointments`;
CREATE TABLE `appointments` (
  `appointment_id` int NOT NULL,
  `client_id` int NOT NULL,
  `dentist_id` int NOT NULL,
  `service_id` int NOT NULL,
  `appointment_datetime` datetime NOT NULL,
  `status` enum('запланировано','проведено','отменено') DEFAULT 'запланировано',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `appointments`
--

INSERT INTO `appointments` (`appointment_id`, `client_id`, `dentist_id`, `service_id`, `appointment_datetime`, `status`, `created_at`) VALUES
(1, 1, 1, 1, '2026-05-25 10:00:00', 'отменено', '2026-05-19 01:55:24'),
(2, 2, 2, 3, '2026-05-25 11:30:00', 'запланировано', '2026-05-19 01:55:24'),
(3, 3, 3, 4, '2026-05-26 09:00:00', 'запланировано', '2026-05-19 01:55:24'),
(4, 4, 1, 5, '2026-05-27 14:00:00', 'отменено', '2026-05-19 01:55:24'),
(5, 1, 2, 2, '2026-06-01 12:15:00', 'отменено', '2026-05-19 01:55:24'),
(7, 1, 3, 1, '2026-05-30 16:42:00', 'проведено', '2026-05-21 07:41:50');

-- --------------------------------------------------------

--
-- Структура таблицы `clients`
--
-- Создание: Май 19 2026 г., 01:52
-- Последнее обновление: Май 21 2026 г., 08:08
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `client_id` int NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `patronymic` varchar(50) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `birth_date` date NOT NULL,
  `birth_day` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `clients`
--

INSERT INTO `clients` (`client_id`, `last_name`, `first_name`, `patronymic`, `phone`, `email`, `birth_date`, `birth_day`) VALUES
(1, 'Иванов', 'Иван', 'Иванович', '+79123456789', 'ivanov@example.com', '1985-05-15', '0000-00-00'),
(2, 'Петрова', 'Мария', 'Сергеевна', '+79224567890', 'petrova@example.com', '1992-11-23', '0000-00-00'),
(3, 'Сидоров', 'Алексей', 'Владимирович', '+79335678901', 'sidorov@example.com', '1978-03-02', '0000-00-00'),
(4, 'Козлова', 'Елена', 'Анатольевна', '+79446789012', 'kozlovae@example.com', '2000-07-19', '0000-00-00'),
(5, 'Морозов', 'Дмитрий', 'Павлович', '+79557890123', 'morozov@example.com', '1995-12-01', '0000-00-00');

-- --------------------------------------------------------

--
-- Структура таблицы `dentists`
--
-- Создание: Май 19 2026 г., 01:52
-- Последнее обновление: Май 21 2026 г., 08:09
--

DROP TABLE IF EXISTS `dentists`;
CREATE TABLE `dentists` (
  `dentist_id` int NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `specialization` enum('терапевт','хирург','ортодонт') NOT NULL,
  `phone` varchar(20) NOT NULL,
  `cabinet_number` int NOT NULL
) ;

--
-- Дамп данных таблицы `dentists`
--

INSERT INTO `dentists` (`dentist_id`, `last_name`, `first_name`, `specialization`, `phone`, `cabinet_number`) VALUES
(1, 'Кузнецова', 'Ольга', 'терапевт', '+79012345678', 3),
(2, 'Смирнов', 'Андрей', 'хирург', '+79023456789', 7),
(3, 'Васильева', 'Татьяна', 'ортодонт', '+79034567890', 12),
(4, 'Николаев', 'Денис', 'терапевт', '+79045678901', 4);

-- --------------------------------------------------------

--
-- Структура таблицы `medical_cards`
--
-- Создание: Май 19 2026 г., 01:52
-- Последнее обновление: Май 19 2026 г., 02:23
--

DROP TABLE IF EXISTS `medical_cards`;
CREATE TABLE `medical_cards` (
  `card_id` int NOT NULL,
  `client_id` int NOT NULL,
  `diagnoses` text,
  `contraindications` text,
  `last_visit_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `medical_cards`
--

INSERT INTO `medical_cards` (`card_id`, `client_id`, `diagnoses`, `contraindications`, `last_visit_date`) VALUES
(1, 1, 'Кариес верхних моляров', NULL, '2025-12-10'),
(2, 2, 'Пародонтит', 'Аллергия на лидокаин', '2026-01-15'),
(3, 3, NULL, NULL, NULL),
(4, 4, 'Неправильный прикус', NULL, '2026-03-05'),
(5, 5, 'Кариес', NULL, '2026-02-00');

-- --------------------------------------------------------

--
-- Структура таблицы `services`
--
-- Создание: Май 19 2026 г., 01:52
-- Последнее обновление: Май 21 2026 г., 08:09
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
  `service_id` int NOT NULL,
  `service_name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `duration_minutes` int NOT NULL
) ;

--
-- Дамп данных таблицы `services`
--

INSERT INTO `services` (`service_id`, `service_name`, `price`, `duration_minutes`) VALUES
(1, 'Осмотр и консультация', '150560.00', 30),
(2, 'Лечение кариеса', '3500.00', 60),
(3, 'Удаление зуба', '4500.00', 45),
(4, 'Установка брекетов', '25000.00', 90),
(5, 'Профессиональная чистка', '2500.00', 40);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`),
  ADD UNIQUE KEY `unique_slot` (`dentist_id`,`appointment_datetime`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `service_id` (`service_id`);

--
-- Индексы таблицы `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Индексы таблицы `dentists`
--
ALTER TABLE `dentists`
  ADD PRIMARY KEY (`dentist_id`);

--
-- Индексы таблицы `medical_cards`
--
ALTER TABLE `medical_cards`
  ADD PRIMARY KEY (`card_id`),
  ADD UNIQUE KEY `unique_client_card` (`client_id`);

--
-- Индексы таблицы `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`),
  ADD UNIQUE KEY `service_name` (`service_name`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointment_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `clients`
--
ALTER TABLE `clients`
  MODIFY `client_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `dentists`
--
ALTER TABLE `dentists`
  MODIFY `dentist_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `medical_cards`
--
ALTER TABLE `medical_cards`
  MODIFY `card_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`dentist_id`) REFERENCES `dentists` (`dentist_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `appointments_ibfk_3` FOREIGN KEY (`service_id`) REFERENCES `services` (`service_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `medical_cards`
--
ALTER TABLE `medical_cards`
  ADD CONSTRAINT `medical_cards_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
